﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_Logica
{
    public partial class Frm1 : Form
    {
        public Frm1()
        {
            InitializeComponent();
        }

        private void btnNum1_Click (object sender, EventArgs e) 
        {
            //Capturar os valores da tela
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text0;
            float soma;

            //Realizar a soma
            soma = num1 + num3;

            //Mostrar o resultado
            MessageBox.Show("Soma = " + soma);
        }


        private void btnNum2_Click (object sender, EventArgs e)
        {
            //Capturar os valores da tela
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text)
            float media

            //Calcular a media
            média = (num1 + num2 + num3 ) / 3

            //Mostrar o resultado
            MessageBox.Show("Média =" + media
        }

        private void btnNum3_Click (object sender, EventArgs e)
        {
            //Capturar os valores da tela
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text)
            float porc1, porc2, porc3;  

            //Cálculos
            porc1 = num1 / (num1 + num2 + num3) *100
            porc2= num2/ (num1 + num2 + num3) * 100
             porc3= num3 (num1 + num2 + num3) * 100)

            //Mostrar resultados
            MessageBox.Show("Porcentagem de num1 =" + porc1);
            MessageBox.Show("Porcentagem de num2=" + porc2);
            MessageBox.Show("Porcentagem de num3=" + porc3);
        }
    }
}
