﻿namespace AppTestePratico_MariaClara2B1
{
    partial class frmQuestao1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmQuestao1));
            this.pnlTopo = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.pnlPrincipal = new System.Windows.Forms.Panel();
            this.lblBroas = new System.Windows.Forms.Label();
            this.lblPaes = new System.Windows.Forms.Label();
            this.txtQntPaes = new System.Windows.Forms.TextBox();
            this.txtQntbroas = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.pnlFinal = new System.Windows.Forms.Panel();
            this.lblValor = new System.Windows.Forms.Label();
            this.lblCifrao = new System.Windows.Forms.Label();
            this.pnlTopo.SuspendLayout();
            this.pnlPrincipal.SuspendLayout();
            this.pnlFinal.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTopo
            // 
            this.pnlTopo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.pnlTopo.Controls.Add(this.lblTitulo);
            this.pnlTopo.Location = new System.Drawing.Point(0, -8);
            this.pnlTopo.Name = "pnlTopo";
            this.pnlTopo.Size = new System.Drawing.Size(800, 106);
            this.pnlTopo.TabIndex = 0;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(18, 47);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(136, 29);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Questão 01";
            // 
            // pnlPrincipal
            // 
            this.pnlPrincipal.BackColor = System.Drawing.Color.Orange;
            this.pnlPrincipal.Controls.Add(this.pnlFinal);
            this.pnlPrincipal.Controls.Add(this.lblBroas);
            this.pnlPrincipal.Controls.Add(this.lblPaes);
            this.pnlPrincipal.Controls.Add(this.txtQntPaes);
            this.pnlPrincipal.Controls.Add(this.txtQntbroas);
            this.pnlPrincipal.Controls.Add(this.btnCalcular);
            this.pnlPrincipal.Location = new System.Drawing.Point(0, 98);
            this.pnlPrincipal.Name = "pnlPrincipal";
            this.pnlPrincipal.Size = new System.Drawing.Size(800, 358);
            this.pnlPrincipal.TabIndex = 0;
            // 
            // lblBroas
            // 
            this.lblBroas.AutoSize = true;
            this.lblBroas.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBroas.Location = new System.Drawing.Point(18, 110);
            this.lblBroas.Name = "lblBroas";
            this.lblBroas.Size = new System.Drawing.Size(239, 29);
            this.lblBroas.TabIndex = 6;
            this.lblBroas.Text = "Quantidade de broas";
            this.lblBroas.Click += new System.EventHandler(this.lblBroas_Click);
            // 
            // lblPaes
            // 
            this.lblPaes.AutoSize = true;
            this.lblPaes.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPaes.Location = new System.Drawing.Point(18, 18);
            this.lblPaes.Name = "lblPaes";
            this.lblPaes.Size = new System.Drawing.Size(231, 29);
            this.lblPaes.TabIndex = 5;
            this.lblPaes.Text = "Quantidade de pães";
            // 
            // txtQntPaes
            // 
            this.txtQntPaes.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQntPaes.Location = new System.Drawing.Point(23, 60);
            this.txtQntPaes.Name = "txtQntPaes";
            this.txtQntPaes.Size = new System.Drawing.Size(176, 35);
            this.txtQntPaes.TabIndex = 1;
            // 
            // txtQntbroas
            // 
            this.txtQntbroas.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQntbroas.Location = new System.Drawing.Point(23, 142);
            this.txtQntbroas.Name = "txtQntbroas";
            this.txtQntbroas.Size = new System.Drawing.Size(176, 35);
            this.txtQntbroas.TabIndex = 2;
            this.txtQntbroas.TextChanged += new System.EventHandler(this.txtQ_TextChanged);
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(23, 202);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(176, 41);
            this.btnCalcular.TabIndex = 3;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.button1_Click);
            // 
            // pnlFinal
            // 
            this.pnlFinal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.pnlFinal.Controls.Add(this.lblCifrao);
            this.pnlFinal.Controls.Add(this.lblValor);
            this.pnlFinal.Location = new System.Drawing.Point(-31, 259);
            this.pnlFinal.Name = "pnlFinal";
            this.pnlFinal.Size = new System.Drawing.Size(828, 107);
            this.pnlFinal.TabIndex = 1;
            // 
            // lblValor
            // 
            this.lblValor.AutoSize = true;
            this.lblValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValor.Location = new System.Drawing.Point(49, 26);
            this.lblValor.Name = "lblValor";
            this.lblValor.Size = new System.Drawing.Size(174, 29);
            this.lblValor.TabIndex = 7;
            this.lblValor.Text = "Valor a pagar:  ";
            // 
            // lblCifrao
            // 
            this.lblCifrao.AutoSize = true;
            this.lblCifrao.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCifrao.Location = new System.Drawing.Point(245, 26);
            this.lblCifrao.Name = "lblCifrao";
            this.lblCifrao.Size = new System.Drawing.Size(43, 29);
            this.lblCifrao.TabIndex = 7;
            this.lblCifrao.Text = "R$";
//            this.lblCifrao.Click += new System.EventHandler(this.lblCifrao_Click);
            // 
            // frmQuestao1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pnlPrincipal);
            this.Controls.Add(this.pnlTopo);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmQuestao1";
            this.Text = "Atividade";
            this.pnlTopo.ResumeLayout(false);
            this.pnlTopo.PerformLayout();
            this.pnlPrincipal.ResumeLayout(false);
            this.pnlPrincipal.PerformLayout();
            this.pnlFinal.ResumeLayout(false);
            this.pnlFinal.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTopo;
        private System.Windows.Forms.Panel pnlPrincipal;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.TextBox txtQntPaes;
        private System.Windows.Forms.TextBox txtQntbroas;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblBroas;
        private System.Windows.Forms.Label lblPaes;
        private System.Windows.Forms.Panel pnlFinal;
        private System.Windows.Forms.Label lblValor;
        private System.Windows.Forms.Label lblCifrao;
    }
}

