﻿namespace AppTestePratico_MariaClara2B1
{
    partial class FrmLoja
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlInicio = new System.Windows.Forms.Panel();
            this.pnlPrincipal = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblCamisasP = new System.Windows.Forms.Label();
            this.lblCamisasM = new System.Windows.Forms.Label();
            this.lblCamisasG = new System.Windows.Forms.Label();
            this.txtQntCamisasP = new System.Windows.Forms.TextBox();
            this.txtQntCamisasM = new System.Windows.Forms.TextBox();
            this.txtQntCamisasG = new System.Windows.Forms.TextBox();
            this.pnlFinal = new System.Windows.Forms.Panel();
            this.lblValor = new System.Windows.Forms.Label();
            this.lblCifrao = new System.Windows.Forms.Label();
            this.btnComprar = new System.Windows.Forms.Button();
            this.pnlInicio.SuspendLayout();
            this.pnlPrincipal.SuspendLayout();
            this.pnlFinal.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlInicio
            // 
            this.pnlInicio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(224)))), ((int)(((byte)(254)))));
            this.pnlInicio.Controls.Add(this.lblTitulo);
            this.pnlInicio.Location = new System.Drawing.Point(-14, -3);
            this.pnlInicio.Name = "pnlInicio";
            this.pnlInicio.Size = new System.Drawing.Size(826, 92);
            this.pnlInicio.TabIndex = 0;
            // 
            // pnlPrincipal
            // 
            this.pnlPrincipal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(175)))), ((int)(((byte)(204)))));
            this.pnlPrincipal.Controls.Add(this.btnComprar);
            this.pnlPrincipal.Controls.Add(this.pnlFinal);
            this.pnlPrincipal.Controls.Add(this.txtQntCamisasG);
            this.pnlPrincipal.Controls.Add(this.txtQntCamisasM);
            this.pnlPrincipal.Controls.Add(this.txtQntCamisasP);
            this.pnlPrincipal.Controls.Add(this.lblCamisasP);
            this.pnlPrincipal.Controls.Add(this.lblCamisasM);
            this.pnlPrincipal.Controls.Add(this.lblCamisasG);
            this.pnlPrincipal.Location = new System.Drawing.Point(-14, 86);
            this.pnlPrincipal.Name = "pnlPrincipal";
            this.pnlPrincipal.Size = new System.Drawing.Size(826, 398);
            this.pnlPrincipal.TabIndex = 0;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(26, 38);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(212, 29);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Loja de Camisetas";
            this.lblTitulo.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblCamisasP
            // 
            this.lblCamisasP.AutoSize = true;
            this.lblCamisasP.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCamisasP.Location = new System.Drawing.Point(39, 24);
            this.lblCamisasP.Name = "lblCamisasP";
            this.lblCamisasP.Size = new System.Drawing.Size(128, 29);
            this.lblCamisasP.TabIndex = 1;
            this.lblCamisasP.Text = "Camisas P";
            // 
            // lblCamisasM
            // 
            this.lblCamisasM.AutoSize = true;
            this.lblCamisasM.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCamisasM.Location = new System.Drawing.Point(39, 107);
            this.lblCamisasM.Name = "lblCamisasM";
            this.lblCamisasM.Size = new System.Drawing.Size(132, 29);
            this.lblCamisasM.TabIndex = 2;
            this.lblCamisasM.Text = "Camisas M";
            // 
            // lblCamisasG
            // 
            this.lblCamisasG.AutoSize = true;
            this.lblCamisasG.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCamisasG.Location = new System.Drawing.Point(39, 186);
            this.lblCamisasG.Name = "lblCamisasG";
            this.lblCamisasG.Size = new System.Drawing.Size(130, 29);
            this.lblCamisasG.TabIndex = 3;
            this.lblCamisasG.Text = "Camisas G";
            // 
            // txtQntCamisasP
            // 
            this.txtQntCamisasP.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQntCamisasP.Location = new System.Drawing.Point(44, 56);
            this.txtQntCamisasP.Name = "txtQntCamisasP";
            this.txtQntCamisasP.Size = new System.Drawing.Size(127, 35);
            this.txtQntCamisasP.TabIndex = 4;
            // 
            // txtQntCamisasM
            // 
            this.txtQntCamisasM.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQntCamisasM.Location = new System.Drawing.Point(40, 139);
            this.txtQntCamisasM.Name = "txtQntCamisasM";
            this.txtQntCamisasM.Size = new System.Drawing.Size(127, 35);
            this.txtQntCamisasM.TabIndex = 5;
            // 
            // txtQntCamisasG
            // 
            this.txtQntCamisasG.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQntCamisasG.Location = new System.Drawing.Point(40, 218);
            this.txtQntCamisasG.Name = "txtQntCamisasG";
            this.txtQntCamisasG.Size = new System.Drawing.Size(127, 35);
            this.txtQntCamisasG.TabIndex = 6;
            // 
            // pnlFinal
            // 
            this.pnlFinal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(224)))), ((int)(((byte)(254)))));
            this.pnlFinal.Controls.Add(this.lblCifrao);
            this.pnlFinal.Controls.Add(this.lblValor);
            this.pnlFinal.Location = new System.Drawing.Point(14, 331);
            this.pnlFinal.Name = "pnlFinal";
            this.pnlFinal.Size = new System.Drawing.Size(826, 97);
            this.pnlFinal.TabIndex = 1;
            // 
            // lblValor
            // 
            this.lblValor.AutoSize = true;
            this.lblValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValor.Location = new System.Drawing.Point(25, 18);
            this.lblValor.Name = "lblValor";
            this.lblValor.Size = new System.Drawing.Size(136, 29);
            this.lblValor.TabIndex = 1;
            this.lblValor.Text = "Valor Total:";
            this.lblValor.Click += new System.EventHandler(this.lblValor_Click);
            // 
            // lblCifrao
            // 
            this.lblCifrao.AutoSize = true;
            this.lblCifrao.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCifrao.Location = new System.Drawing.Point(205, 18);
            this.lblCifrao.Name = "lblCifrao";
            this.lblCifrao.Size = new System.Drawing.Size(43, 29);
            this.lblCifrao.TabIndex = 2;
            this.lblCifrao.Text = "R$";
            this.lblCifrao.Click += new System.EventHandler(this.lblCifrao_Click);
            // 
            // btnComprar
            // 
            this.btnComprar.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnComprar.Location = new System.Drawing.Point(40, 268);
            this.btnComprar.Name = "btnComprar";
            this.btnComprar.Size = new System.Drawing.Size(127, 47);
            this.btnComprar.TabIndex = 3;
            this.btnComprar.Text = "Comprar";
            this.btnComprar.UseVisualStyleBackColor = true;
            this.btnComprar.Click += new System.EventHandler(this.btnComprar_Click);
            // 
            // FrmLoja
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(806, 486);
            this.Controls.Add(this.pnlPrincipal);
            this.Controls.Add(this.pnlInicio);
            this.Name = "FrmLoja";
            this.Text = "FrmLoja";
            this.Load += new System.EventHandler(this.FrmLoja_Load);
            this.pnlInicio.ResumeLayout(false);
            this.pnlInicio.PerformLayout();
            this.pnlPrincipal.ResumeLayout(false);
            this.pnlPrincipal.PerformLayout();
            this.pnlFinal.ResumeLayout(false);
            this.pnlFinal.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlInicio;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Panel pnlPrincipal;
        private System.Windows.Forms.TextBox txtQntCamisasG;
        private System.Windows.Forms.TextBox txtQntCamisasM;
        private System.Windows.Forms.TextBox txtQntCamisasP;
        private System.Windows.Forms.Label lblCamisasP;
        private System.Windows.Forms.Label lblCamisasM;
        private System.Windows.Forms.Label lblCamisasG;
        private System.Windows.Forms.Button btnComprar;
        private System.Windows.Forms.Panel pnlFinal;
        private System.Windows.Forms.Label lblCifrao;
        private System.Windows.Forms.Label lblValor;
    }
}