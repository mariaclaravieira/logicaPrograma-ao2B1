﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppTestePratico_MariaClara2B1
{
    public partial class frmQuestao1 : Form
    {
        public frmQuestao1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Pegar os valores na tela
            int QntPaes = int.Parse(txtQntPaes.Text);
            int Qntbroas = int.Parse(txtQntbroas.Text);
            float total;

            //Fazer o cálculo
            total = Qntbroas *1.50f + QntPaes *0.12f;

            //Mostrar o resultado em uma label
            lblCifrao.Text = "R$" + total;

        }

        private void lblBroas_Click(object sender, EventArgs e)
        {

        }

        private void txtQ_TextChanged(object sender, EventArgs e)
        {

        }

    }
}
